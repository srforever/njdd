 /*
 	Controller.js

 	Ties all app dependencies together, including UI interaction, user management, and data storage.
 */
(function(ctrl){ 

	ctrl.doSomething = function() {
		
	}

}(window.controller = window.controller || {}));