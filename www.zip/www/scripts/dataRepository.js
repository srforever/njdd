/*
	dataRepository.js

	Encapsulate any external data source/API for dependency injection purposes.
*/