README

PhoneGap Build's config.xml has references to all icons/splash screens. Place them here.